# 3080TI: one image, then a short video

1. Extract this complete ZIP into a new folder of your own. All companion files are together; there is no second workflow ZIP to find.
2. Read [the exact installation note](ANLEITUNG/12-NVIDIA-INSTALLATION-START.txt) and keep existing installations intact. AMD and NVIDIA use different routes.
3. Check [model files and locations](ANLEITUNG/06-MODELLE-UND-ORDNER.txt). Weights are separate downloads and are not included here.
4. Read [the browser import note](ANLEITUNG/13-UI-WORKFLOWS-IMPORT.txt) and open [the greeting-card UI graph](UI-REKONSTRUIERT/3080-karten-qwen2512-4f443da2.ui.json) in ComfyUI. API-ORIGINAL contains a different format and remains an archival source.
5. Check missing nodes and assigned weights. Enter your own short card text. First keep the documented parameters of this template, then change one setting at a time. Inspect spelling and the saved PNG.
6. Open [the LTX UI graph](UI-REKONSTRUIERT/3080-ltx-LTX-2.5%20distilled-5a80049d.ui.json). Load your own non-sensitive image and check the matching LTX variant and memory settings in the notes. Frames/FPS gives the expected length in seconds. Enter a short motion request and conduct a small experiment.
7. Record actual results and errors in [DEIN-VERSUCH.csv](DEIN-VERSUCH.csv), and preserve image, video and used graph together. Read [model license notes](ANLEITUNG/15-LIZENZEN-QUELLEN.txt).

Original API files come from historical tests. UI graphs are reconstructed import templates; this edition does not claim a new complete installation or UI execution. 12/24GB VRAM or shared Strix Halo memory do not guarantee arbitrary models fit. Other AMD graphics cards and Macs remain separately untested. No private input images or weights are included.

Source: unchanged published companions from dolmario/ki-video-workflows at Git head ab53acaef805f6e01f17a5e35835115d73361539, folder 41-AI-Images-Video-12GB-RTX-3080-Ti-English. New MOSS films are still in preparation.
