DOLMARIO – LOKALES TUTORIAL-BEGLEITPAKET
UI-REKONSTRUIERT: .ui.json in ComfyUI laden. Vier importgeprüfte UI-Pfade.
API-ORIGINAL: unveränderte Testgraph-Inhalte; nicht mit UI-Dateien verwechseln.
ANLEITUNG/12: Installation und Start. 13: UI-Import. 14: Modell-Dateien. 15: Lizenzen.
Eigene erlaubte Eingabebilder in LoadImage wählen; keine Fotos oder Modelle enthalten.
Keine neuen GPU-Läufe zur Validierung dieser UI-Rekonstruktionen durchgeführt.
Historische Tests und Fehler sind keine Garantie für dein System.
Begleitpaket zur Dolmario-Videoreihe; Installationsanleitung und Quellen liegen in ANLEITUNG.
