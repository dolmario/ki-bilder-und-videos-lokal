# 3090TI: ein Bild, dann ein kurzes Video

1. Dieses ZIP vollständig in einen eigenen neuen Ordner entpacken. Alle Begleitdateien sind hier zusammen; du musst kein weiteres Workflow-ZIP suchen.
2. [Die genaue Installationsbeilage](ANLEITUNG/12-NVIDIA-INSTALLATION-START.txt) lesen. Eine vorhandene Installation erhalten. AMD und NVIDIA verwenden unterschiedliche Wege.
3. [Die Modelldateien und Ordner](ANLEITUNG/06-MODELLE-UND-ORDNER.txt) abgleichen. Modellgewichte sind getrennte Downloads und nicht in diesem ZIP enthalten.
4. [Den Browser-Import](ANLEITUNG/13-UI-WORKFLOWS-IMPORT.txt) lesen und [den Grußkarten-UI-Graph](UI-REKONSTRUIERT/3090-karten-qwen2512-d6ce7839.ui.json) in ComfyUI öffnen. API-ORIGINAL sind andere Dateiformate und bleiben Archivquellen.
5. Fehlende Nodes und Modellnamen prüfen; deinen eigenen kurzen Kartentext im Prompt eintragen. Zunächst die dokumentierten Werte dieser Vorlage behalten, danach jeweils nur eine Änderung testen. Schrift und gespeicherte PNG prüfen.
6. [Den LTX-UI-Graph](UI-REKONSTRUIERT/3090-ltx-LTX-2.5%20distilled-1b13cc8d.ui.json) öffnen. Dein eigenes unkritisches Bild laden, die passende LTX-Datei/Variante und Speicheroptionen aus den Beilagen prüfen. Frames/FPS ergibt die erwartete Sekundenlänge. Eigenen Bewegungswunsch eintragen und einen kleinen Versuch durchführen.
7. Dein tatsächliches Ergebnis und Fehler in [DEIN-VERSUCH.csv](DEIN-VERSUCH.csv) dokumentieren; Bild, Video und verwendeten Graph zusammen sichern. [Modelllizenzen](ANLEITUNG/15-LIZENZEN-QUELLEN.txt) nachlesen.

Die enthaltenen ursprünglichen API-Dateien gehören zu historischen Tests. UI-Dateien sind rekonstruierte Importvorlagen; eine neue vollständige Installation oder UI-Ausführung wurde für diese Ausgabe nicht durchgeführt. 12/24GB VRAM beziehungsweise gemeinsamer Strix-Halo-Speicher garantieren keine beliebige Modellgröße. Andere AMD-Grafikkarten und Macs bleiben getrennt praktisch ungetestet. Keine privaten Eingabebilder oder Gewichte enthalten.

Herkunft: unveränderte veröffentlichte Begleitdateien aus dolmario/ki-video-workflows, Git-Head ab53acaef805f6e01f17a5e35835115d73361539, Ordner 42-Fotos-kolorieren-animieren-RTX-3090-Ti. Neue MOSS-Filme sind noch in Vorbereitung.
