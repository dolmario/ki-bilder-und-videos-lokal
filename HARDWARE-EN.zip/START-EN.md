# Your first image and short video with ComfyUI

Start with one result. Choose exactly your hardware and language below. Extract its WORKFLOWS.zip completely and read the installation/model notes first. These archives preserve the exact historical test setup. A fresh installation has not been performed for this new edition.

## 1. Choose your folder

- Strix Halo / EVO-X2: ARCHIV/39-AI-Images-Video-Without-Nvidia-AMD-Strix-Halo-English.
- RTX3080Ti: ARCHIV/41-AI-Images-Video-12GB-RTX-3080-Ti-English.
- RTX3090Ti: ARCHIV/43-Colourise-Animate-Photos-RTX-3090-Ti-English.

The AMD environment and NVIDIA portable installation are different routes. Strix Halo64GB shared memory is not extra discrete VRAM. RTX12GB/24GB alone do not prove every workload fits. Exact machines and constraints are in the notes. Other AMD graphics cards and Macs are not practically tested targets here.

## 2. Separate runtime, weights and graph

ComfyUI is the runtime; weights go into the specified model directories; JSON stores graph connections. The ZIP contains guides and workflows, not missing model weights. Read the official-download/model-location notes and the hardware-specific installation note12. Keep existing installations intact.

## 3. Open the correct graph

Note13 explains UI-REKONSTRUIERT versus API-ORIGINAL. The former contains reconstructed browser graphs; the latter stores historical API prompts. An API prompt is not a browser-importable graph. The reconstructed UI is not claimed as a new complete execution. Check missing nodes, model assignments and input files before starting.

## 4. Create one image first

Start with the greeting-card task and a short text of your own. Read prompt note08 and input-to-output note09. Follow text encoder, model, sampler, VAE and SaveImage. First keep the documented parameters of your chosen template and change only the prompt. Check spelling, subject and saved file. Preserve the actual output together with its graph.

## 5. Animate your own image next

Choose the matching hardware LTX-2.5 UI graph and use your own non-sensitive image. Check all LTX weights/nodes in the notes; FLUX files do not replace them. Distilled/dev, quantization, steps and memory options belong to your selected template. Request a short motion, check resolution, frame count and FPS, and start with a small experiment. Seconds = frames/FPS. Record what the run actually produced.

## 6. Keep an honest experiment log

Read the actual error for missing weights/nodes or memory failures. Avoid mixing unrelated model packages. Connection/test notes are historical evidence, not a guarantee for your machine. Record graph, models, parameters, errors and real outputs in DEIN-VERSUCH.csv. Keep new results distinct from archived tests. Read license note15. Private photos and secrets remain on your own computer.

New MOSS films with our fictional presenter and DOLMARIO AI llama are in preparation. Existing movies are not presented as newly made films.
