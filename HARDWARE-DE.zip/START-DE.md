# Dein erstes Bild und dein erstes kurzes Video mit ComfyUI

Beginne mit einem einzigen Ergebnis. Wähle unten genau deinen Rechner und deine Sprache. Entpacke dessen WORKFLOWS.zip vollständig; lies zuerst die Installations- und Modelldateien. Die Archivdateien halten den damaligen konkreten Teststand fest. Eine neue Installation wurde für diese Neuauflage noch nicht durchgeführt.

## 1. Den passenden Ordner wählen

- Strix Halo / EVO-X2: ARCHIV/38-KI-Bilder-Videos-ohne-Nvidia-AMD-Strix-Halo.
- RTX3080Ti: ARCHIV/40-KI-Bilder-Videos-12GB-RTX-3080-Ti.
- RTX3090Ti: ARCHIV/42-Fotos-kolorieren-animieren-RTX-3090-Ti.

Das AMD-Paket und das NVIDIA-Portable sind verschiedene Installationswege. 64GB gemeinsamer Speicher des Strix Halo sind kein zusätzlicher separater Grafikspeicher;12GB/24GB der RTX-Karten sagen allein nicht, ob jedes Modell passt. Die genauen Rechnerstände und Grenzen stehen in den Beilagen. Andere AMD-Grafikkarten und Macs sind hier keine praktisch geprüften Zielsysteme.

## 2. Programm, Modelle und Workflow trennen

ComfyUI ist das Programm. Die Modellgewichte liegen separat in den genannten Modellordnern. Der JSON-Workflow beschreibt die Verbindungen. Es fehlen keine Gewichte im ZIP: Es enthält bewusst nur Anleitungen und Workflows. Nutze05-DOWNLOADS-OFFIZIELL.txt,06-MODELLE-UND-ORDNER.txt und die jeweilige12-Installationsbeilage; Namen können je Hardware leicht abweichen. Keine bestehende Installation überschreiben.

## 3. Im Browser den richtigen Workflow öffnen

13-UI-WORKFLOWS-IMPORT.txt erklärt den Unterschied: UI-REKONSTRUIERT enthält für den Browser rekonstruierte Graphen; API-ORIGINAL enthält historische API-Prompts. Ein API-Prompt ist kein direkt importierbarer UI-Graph. Die rekonstruierte Oberfläche wurde nicht als neuer vollständiger Versuch behauptet. Prüfe fehlende Nodes, Modellzuordnung und Eingabedatei vor dem Start.

## 4. Erst ein Bild

Beginne mit der Grußkarten-Aufgabe und einem kurzen eigenen Text. Lies08-PROMPTS.txt und09-WORKFLOW-INPUT-BIS-OUTPUT.txt. Verfolge Eingabe, Textencoder, Modell, Sampler, VAE und SaveImage. Übernimm zunächst die dokumentierten Werte deiner ausgewählten Vorlage; ändere dann nur den Prompt. Prüfe Schrift, Bildinhalt und gespeicherte Datei. Sichere das tatsächliche Ergebnis und den dazugehörigen Workflow.

## 5. Dann das eigene Bild animieren

Wähle den hardwarepassenden LTX-2.5-UI-Graph und lade ein eigenes unkritisches Bild. Gleiche sämtliche LTX-Dateien und Nodes mit den Beilagen ab; FLUX-Gewichte ersetzen keine LTX-Gewichte. Distilled/dev, Quantisierung, Schritte und Speicheroptionen gehören zur gewählten Vorlage. Gib einen kurzen Bewegungswunsch vor, kontrolliere Auflösung, Framezahl und FPS und plane zunächst nur einen kleinen Versuch. Dauer in Sekunden = Frames/FPS. Sage nach dem Lauf ausdrücklich, was tatsächlich erzeugt wurde.

## 6. Fehler und eigenes Protokoll

Bei fehlendem Modell/Node oder Speicherfehler zuerst die echte Fehlermeldung lesen. Keine zufällige Mischung anderer Modellpakete.10-NODE-VERBINDUNGEN-TESTBELEGE.txt enthält Archivbelege, keine Garantie für deine Installation. Trage in DEIN-VERSUCH.csv Modell, Graph, Parameter, Fehler und tatsächlichen Output ein. Die historischen Workflows und Zahlen bleiben Quellen; neue eigene Ergebnisse werden separat protokolliert. Lizenzen stehen in15-LIZENZEN-QUELLEN.txt. Private Fotos und Geheimnisse bleiben auf deinem Rechner.

Neue MOSS-Tutorialfilme mit eigener fiktiver Moderatorin und DOLMARIO AI Lama sind noch in Vorbereitung. Vorhandene Filme werden nicht als neue Filme ausgegeben.
